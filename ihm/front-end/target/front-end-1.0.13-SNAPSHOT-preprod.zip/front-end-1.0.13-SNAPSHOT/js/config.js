//URL de base du service web REST
var REST_SERVICE_URL="https://intranet-preproduction.inra.fr/backend-reporting-activites/";
