/* Created by Smile */

/*
 * Rassemble des fonctions permettants d'utiliser le service web REST
 */
(function($){
    
    $.reporting = {};
    $.reporting.restBaseUrl = REST_SERVICE_URL;
    $.reporting.xhrFields = {
        withCredentials: true
    };
    
    /*
     * Configuration du back-end.
     * $.reporting.loadBackendConf doit être appelée pour charger ces données.
     */
    $.reporting.backendConf = {};
    
    /*
     * Effectue une requête sur le service web
     * actionUrl: URL de l'action (à partir de action/)
     * onSuccess: fonction appelée si la requête réussie, les données sont passées en paramètre
     * onError: fonction appelée si la requête échoue (optionnel), reçoit le status HTTP et la réponse JSON en paramètre
     */
    $.reporting.getJSON = function(actionUrl, onSuccess, onError){
        $.reporting.ajax({
            url: $.reporting.buildRequestUrl(actionUrl),
            xhrFields: $.reporting.xhrFields,
            success: onSuccess,
            error: function(xhr){
                if(onError != undefined){
                    onError(xhr.status, xhr.responseJSON);
                }
            }
        });
    };
    
    /*
     * Construit une URL abslolue vers les services web.
     */
    $.reporting.buildRequestUrl = function(actionUrl){
        return $.reporting.restBaseUrl+"action/"+actionUrl;
    };
    
    /*
     * Vérifie si l'utilisateur est authentifié.
     * onSuccess: fonction appelée si l'utilisateur est authentifié
     * onError: fonction appelée si l'utilisateur n'est pas authentifié (optionnel)
     */
    $.reporting.checkAuthentication = function(onSuccess, onError){
        $.reporting.ajax({
            url: $.reporting.buildRequestUrl("authentification/verifier"),
            xhrFields: $.reporting.xhrFields,
            success: onSuccess,
            error: onError
        });
    };
    
    /*
     * Effectue un appel ajax
     */
    $.reporting.ajax = function(options){
        if(options.crossDomain === undefined && navigator.appVersion.indexOf("MSIE 9.") != -1){
            //JQuery bugfix with IE < 10
            options.crossDomain = false;
        }
        $.ajax(options);
    };
    
    /*
     * Lance l'authentification de l'utilisateur
     */
    $.reporting.authenticate = function(){
        var authUrl = $.reporting.restBaseUrl
            +"j_spring_cas_security_login?postAuthRedirectUrl="
            +window.location.href;
        window.location.replace(authUrl);
    };
    
    /*
     * Charge la configuration du backend dans $.reporting.backendConf
     * onSuccess: fonction appelée en cas de succès
     * onError: fonction appelée en cas d'erreur
     */
    $.reporting.loadBackendConf = function(onSuccess, onError){
        $.reporting.getJSON("conf", function(data){
            $.reporting.backendConf = data;
            if(onSuccess != undefined){
                onSuccess();
            }
        }, onError);
    };

})(jQuery);
