//URL de base du service web REST
var REST_SERVICE_URL="http://reporting-activites-dev.jouy.inra.fr:8080/backend-reporting-activites/";
