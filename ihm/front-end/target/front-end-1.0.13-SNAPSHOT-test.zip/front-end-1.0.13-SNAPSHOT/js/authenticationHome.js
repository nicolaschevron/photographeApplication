$.reporting.checkAuthentication(function(data){
        $.ihm.loadUserInfos(function() {
            var currentDataTable = null;
            $(document).ready(function(){
                $.ihm.loadDataTableRepportDescriptions();
            });
        });
    },
    function(){
        $.ihm.displayLoggedOutUser();
    }
);
