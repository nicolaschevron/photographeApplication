//URL de base du service web REST
var REST_SERVICE_URL="http://reporting-activites-test.jouy.inra.fr:9080/backend-reporting-activites/";