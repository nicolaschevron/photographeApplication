/* Created by Smile */

/*
 * Rassemble des fonctions permettant de manipuler l'IHM
 */
(function($){
    
    $.ihm = {};
    //Constants
    $.ihm.isAdmin = false;
    $.ihm.dataTableId = "data-table";
    $.ihm.loaderId = "data-table-loader";
    $.ihm.titleId = "rapport-title";
    $.ihm.rapportDateId = "rapport-date";
    $.ihm.exportLinkId = "exportLink";
    $.ihm.ISO8601Regex = /(\d{4})-(\d{2})-(\d{2})T(\d{2})\:(\d{2})\:(\d{2})Z/;
    $.ihm.dataTableLanguage = {
        "sProcessing":     "Traitement en cours...",
        "sSearch":         "Rechercher&nbsp;:",
        "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
        "sInfo":           "Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
        "sInfoEmpty":      "Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments",
        "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
        "sInfoPostFix":    "",
        "sLoadingRecords": "Chargement en cours...",
        "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
        "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
        "oPaginate": {
            "sFirst":      "Premier",
            "sPrevious":   "Pr&eacute;c&eacute;dent",
            "sNext":       "Suivant",
            "sLast":       "Dernier"
        },
        "oAria": {
            "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
            "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
        }
    };
    
    //Variables
    $.ihm.dataTable = undefined;
    $.ihm.colonnes = undefined;
    
    //Ajout des tris personnalisés
    $.ihm.dataTableSortDate = function(a, b){
        if(a == b){
            return 0;
        }
        else {
            var result = 0;
            if(a.length == 10 && b.length == 10){
                var aStr = (a.substr(6, 4)+a.substr(3, 2)+a.substr(0, 2));
                var bStr = (b.substr(6, 4)+b.substr(3, 2)+b.substr(0, 2));
                if(aStr < bStr){
                    result = -1;
                } else if(aStr > bStr){
                    result = 1;
                }
            } else {
                if(a < b){
                    result = -1;
                } else {
                    result = 1;
                }
            }
            return result;
        }
    };
    $(document).ready(function(){
		function removeAccentuatedChar(s) {
            if(s == null) { return ""; }
            var r=s.toLowerCase();
            r = r.replace(new RegExp(/[àáâãäå]/g),"a");
            r = r.replace(new RegExp(/æ/g),"ae");
            r = r.replace(new RegExp(/ç/g),"c");
            r = r.replace(new RegExp(/[èéêë]/g),"e");
            r = r.replace(new RegExp(/[ìíîï]/g),"i");
            r = r.replace(new RegExp(/ñ/g),"n");                
            r = r.replace(new RegExp(/[òóôõö]/g),"o");
            r = r.replace(new RegExp(/œ/g),"oe");
            r = r.replace(new RegExp(/[ùúûü]/g),"u");
            r = r.replace(new RegExp(/[ýÿ]/g),"y");
            return r;
		};
		
		function pre(a) {
			return removeAccentuatedChar(a);
		};
		$.fn.dataTableExt.oSort["html-pre"] = pre;
		$.fn.dataTableExt.oSort["string-pre"] = pre;

        $.fn.dataTableExt.oSort["date-fr-asc"] = $.ihm.dataTableSortDate;
        $.fn.dataTableExt.oSort["date-fr-desc"] = function(a, b){
            return $.ihm.dataTableSortDate(b, a);
        };
    });
    
    /*
     * Charge et affiche la liste des rapports disponibles dans la datatable.
     */
    $.ihm.loadDataTableRepportDescriptions = function(){
        $.ihm.loadDataTable("liste_rapports_description/all", {
            "paging":   false,
            "order":  [[ 0, "asc" ]],
            "info":     false,
            "bFilter":  false,
            'createdRow': function (row, data, index) {
                //Cette fonction permet d'ajouter l'id de l'objet dans l'id du tr html
                $(row).attr('id', data.id); 
            },
            "aoColumnDefs": [{
               "aTargets": [-1], // Column to target
               "mRender": function ( data, type, full ) {
                    // 'full' is the row's data object, and 'data' is this column's data
                    // e.g. 'full[0]' is the comic id, and 'data' is the comic title
                    return '<a href="rapports.html?report=' + data+ '">Voir le rapport</a>';
                }
            }],
            maxTextSize: null
        });
        
        if ($.ihm.isAdmin){
            var selectedLineId = [];
            $("#"+$.ihm.dataTableId).on("init.dt", function(){
                //Cette fonction est appelée à chaque clique sur le tableau et met a jour un tableau avec les ids selectionnés
                $("#"+$.ihm.dataTableId+" tbody").on('click', 'tr', function () {
                    var id = this.id;
                    var index = $.inArray(id, selectedLineId);
                    if ( index === -1 ) {
                        selectedLineId.push(id);
                    } else {
                        selectedLineId.splice(index,1);
                    }
                    $(this).toggleClass('selected');
                });
            });
            
            $('#buttonDatableDesc').append('<button id="buttonEnable">Activer</button>');
            $('#buttonDatableDesc').append('<button id="buttonDisable">Desactiver</button>');
            $('#buttonEnable').click( function () {
                $.ihm.enableReport(true, selectedLineId);
            } );
            $('#buttonDisable').click( function () {
                 $.ihm.enableReport(false, selectedLineId);
            } );
        }
    };
    
    /*
     * Charge et affiche un rapport dans la data table
     * rapportActionUrl: l'url d'action du rapport (à partir du action/)
     * dataTableOptions: options passés au datatable à l'initialisation (optionnel)
     * 
     * dataTableOptions peut contenir:
     * - n'importe quelle option de datatable
     * - maxTextSize: la longueur max d'un texte au moment de l'affichage dans la datatable, null si ignoré
     */
    $.ihm.loadDataTable = function(rapportActionUrlTmp, dataTableOptions){
        var options = $.extend(
            {
                maxTextSize: 200
            },
            dataTableOptions
        );
        
    	var rapportActionUrl = null;
    	if (rapportActionUrlTmp.indexOf('/') == 0) {
    		rapportActionUrl = rapportActionUrlTmp.substr(1);
    	} else {
    		rapportActionUrl = rapportActionUrlTmp;
    	}
        $("#"+$.ihm.loaderId).show();
        //Chargement ajax
        $.reporting.getJSON(rapportActionUrl,
            function(data){
                //Parsing des dates
                var keyToParseDate = [];
                if(data.lignesRapport.length > 0){
                    for(var index in data.colonnesRapport){
                        if(data.colonnesRapport[index].type == "date"){
                            keyToParseDate.push(data.colonnesRapport[index].cle);
                        }
                    }
                    if(keyToParseDate.length > 0){
                        for(var index in data.lignesRapport){
                            for(var keyIndex in keyToParseDate){
                                if(data.lignesRapport[index][keyToParseDate[keyIndex]] != null ){
                                    var dateJson = new Date(data.lignesRapport[index][keyToParseDate[keyIndex]]);
                                    data.lignesRapport[index][keyToParseDate[keyIndex]] = $.ihm.dateToString(new Date(dateJson.getTime()+(dateJson.getTimezoneOffset()*60000)));
                                } else {
                                    data.lignesRapport[index][keyToParseDate[keyIndex]] = "";
                                }
                            }
                        }
                    }
                }
                

                function renderColumn( data, type, full, meta ) {//Limite à 200 caractère le rendu d'une cellule (de type string)
                    if(typeof data == "string"){
                        return type === 'display' && data.length > options.maxTextSize ?
                            '<span title="'+data.replace(new RegExp(/\"/g)," ")+'">'+data.substr( 0, options.maxTextSize )+'...</span>' :data;
                    } else {
                        return data;
                    }
                }
                
                //Préparation des paramètres de la data-table
                $("#" + $.ihm.titleId).html("");
                $("#" + $.ihm.rapportDateId).html("");
                $("#"+$.ihm.dataTableId).empty();
                
                var columns = [];
                for(var index in data.colonnesRapport){
                    var item = data.colonnesRapport[index];
                    var column = {
                        data: item.cle,
                        title: item.libelle
                    };
                    //Surcharge de la méthode de rendu, seulement pour les colonnes où ce n'est pas fait
                    //dans les options.
                    if(options.maxTextSize != null){
                        column.render = renderColumn;
                    }
                    
                    if(keyToParseDate.indexOf(item.cle) != -1){
                        column.type = "date-fr";
                    }
                    columns.push(column);
                }
                
                //Rechargement de la data-table
                if($.ihm.dataTable != undefined){
                    $.ihm.dataTable.api().destroy();
                }
                
                var initOptions = {
                    language: $.ihm.dataTableLanguage,
                    data: data.lignesRapport,
                    "order":  [[ 0, "desc" ]],
                    columns: columns,
                    responsive: true,
                    "deferRender": true,
                    autoWidth: false
                };
                if(dataTableOptions != undefined){
                    initOptions = $.extend(
                        {},
                        dataTableOptions,
                        initOptions
                    );   
                }
                $.ihm.dataTable = $("#"+$.ihm.dataTableId).dataTable(initOptions);
                
                $.ihm.colonnes = data.colonnesRapport;
                
                var restExportUrl = rapportActionUrl.substr(0, rapportActionUrl.indexOf('/') + 1) + "export";
                // Construction du lien d'export
//                $("#"+$.ihm.dataTableId).siblings('.dataTables_filter').append(
//                        '<a id="exportLink" href=""><img src="img/csv-logo.png" alt="Exporter en CSV" /></a>');
                $.ihm.updateExportLink(restExportUrl);
                $("#"+$.ihm.dataTableId).on('search.dt', function() { $.ihm.updateExportLink(restExportUrl) });

                //Hack: trigger de l'event "resize" pour forcer la data-table
                //à redimensionner ses colonnes correctement
                $(window).trigger('resize');
                $(window).trigger('resize');//Une deuxième fois est nécessaire, sinon aucun effet
                
                //Affichage du titre du rapport
                $("#"+$.ihm.titleId).html(data.rapportDescription.titre);
                $("#"+$.ihm.rapportDateId).html("Date de chargement des informations : " + $.util.convertDate(data.rapportDescription.dateDernierImport));
                $("#"+$.ihm.exportLinkId).removeClass("hidden");
                
                //Fin
                $("#"+$.ihm.loaderId).hide();
            },
            $.ihm.handleReportError
        );
    };
    
    /**
     * Gestion des erreurs provenant des appels pour récupérer les données d'un rapport.
     * Affichage d'un message à l'utilisateur.
     */
    $.ihm.handleReportError = function(statusCode, response){
        $("#"+$.ihm.loaderId).hide();
        $("user-message").hide();
        var displayMessage = null;
        var messageClass = null;
        if(statusCode == 400){
            messageClass = "info";
        } else {
            messageClass = "error";
        }
        
        if(response != undefined && response.message != undefined){
            displayMessage = response.message;
        } else if(statusCode == 403){
            displayMessage = "Vous n'&ecirc;tes pas autoris&eacute; &agrave; acc&eacute;der &agrave; ce rapport";
        } else if(statusCode == 404){
            displayMessage = "Ce rapport n'existe pas";
        } else {
            displayMessage = "Une erreur inconnue est survenue";
        }
        $(".user-message").hide();
        $(".user-message."+messageClass).html(displayMessage).show();
    };
    
    /*
     * Met à jour le lien d'export à partir de la datatable
     * restExportUrl: l'url d'action de l'export
     */
    $.ihm.updateExportLink = function(restExportUrl) {
        if ($.ihm.colonnes != undefined) {
            var url = REST_SERVICE_URL + 'action/' + restExportUrl + '?';
            var offset = $.ihm.dataTable.api().order()[0][0];
            var field = $.ihm.colonnes[offset].cle;
            var order = $.ihm.dataTable.api().order()[0][1].toUpperCase();
            
            url = url + 'orderField=' + field + '&order=' + order;
            
            var keyword = $('.dataTables_filter input').val();
            if(keyword != ''){
                url = url + '&keywords=' + keyword;
            }

            $("#"+$.ihm.exportLinkId).removeClass("hidden").attr("href", url );
        }
    };
    
    /*
     * Afficher les informations de l'utilisateur connecté
     * user: information de l'utilisateur récupérés auprès de service REST
     */
    $.ihm.displayLoggedInUser = function(user){
    	$.ihm.isAdmin = user.isAdmin;
    	$("#userInfos").html(user.prenom+" "+user.nom);
        $("#logoutLink").attr("href", REST_SERVICE_URL+"j_spring_security_logout");
        $('.user-unlogged').addClass('hidden');
        $('.user-logged').removeClass('hidden');
    };
    
    /*
     * Affiche les liens/informations pour un utilisateur non-connecté
     */
    $.ihm.displayLoggedOutUser = function(){
        $('.user-unlogged').removeClass('hidden');
        $('.user-logged').addClass('hidden');
    };
    
    /*
     * Affiche les liens/informations pour un utilisateur non-connecté
     */
    $.ihm.enableReport = function(enable, selectedLineId){
    	if(selectedLineId!=""){
    		var actionUrlAccueil = "update_rapport/" + selectedLineId + "/" + enable;
    		$.reporting.getJSON(actionUrlAccueil,function(){location.reload();});
    	}
    };
    
   
    /*
     * Charge et affiche les informations d'un utilisateur, si il est connecté
     */
    $.ihm.loadUserInfos = function(onSuccess) {
        $.reporting.getJSON("utilisateur/informations", function(data){
            $.ihm.displayLoggedInUser(data);
            onSuccess();
        },
        function(){
            $.ihm.displayLoggedOutUser();
        });
    };
    
    /*
     * Initialise l'affichage
     */
    $.ihm.initDisplay = function() {
        $.reporting.loadBackendConf(function(){
            $('#feedbackLink').attr('href', 'mailto:' + $.reporting.backendConf.feedback.email
                                            + '?subject='+$.reporting.backendConf.feedback.subject);
        });
    }
    
    /*
     * Charge le bouton "feedback".
     */
    $.ihm.loadFeedbackMail = function() {
        $.reporting.getJSON("conf/feedback", 
            function(data){
                $('#feedbackLink').attr('href', 'mailto:' + data);
            }, function(){}
        );
    };
    
    //Utilitaires
    $.ihm.dateToString = function(data){
        function pad(str, max){
            str = str.toString();
            return str.length < max ? pad("0" + str, max) : str;
        };
        return ""+pad(data.getDate(), 2)+"/"+pad(data.getMonth()+1, 2)+"/"+data.getFullYear();
    };
    
    
})(jQuery);

